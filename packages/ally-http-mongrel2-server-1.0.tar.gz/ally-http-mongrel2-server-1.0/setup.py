
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Gabriel Nistor',
      author_email='gabriel.nistor@sourcefabric.org',
      classifiers=['Development Status :: 4 - Beta'],
      description='Provides the HTTP mongrel2 server',
      install_requires=['ally-http >= 1.0'],
      keywords=['Ally', 'REST', 'HTTP,mongrel2', 'server'],
      long_description='Similar to the asyncore server but provides support for using \n0MQ messaging in order to communicate with Mongrel2 HTTP server.',
      name='ally-http-mongrel2-server',
      package_data={'': ['*.txt', '*.conf']},
      test_suite='__unit_test__',
      version='1.0'
      )

