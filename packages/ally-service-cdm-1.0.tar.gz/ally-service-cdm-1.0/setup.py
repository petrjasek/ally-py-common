
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Gabriel Nistor',
      author_email='gabriel.nistor@sourcefabric.org',
      classifiers=['Development Status :: 4 - Beta'],
      description='Provides the content delivery manager and support for handling it',
      install_requires=['ally-http >= 1.0'],
      keywords=['Ally', 'REST', 'Content', 'manager', 'service'],
      long_description='This component provide the content delivery management, basically the static resources streaming \nsince REST is only for models, usually the REST models will have references to static files, like media files and \nthe CDM is used for delivery them.',
      name='ally-service-cdm',
      test_suite='__unit_test__',
      version='1.0'
      )

