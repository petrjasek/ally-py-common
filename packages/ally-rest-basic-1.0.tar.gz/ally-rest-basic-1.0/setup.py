
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      author='Gabriel Nistor',
      author_email='gabriel.nistor@sourcefabric.org',
      classifiers=['Development Status :: 4 - Beta'],
      description='The basic ally REST service platform ',
      install_requires=['ally-core-http >= 1.0', 'ally-plugin >= 1.0'],
      keywords=['Ally', 'REST', 'basic', 'service'],
      long_description='The components that represent the basic ally REST service platform.',
      name='ally-rest-basic',
      packages=[],
      version='1.0'
      )

