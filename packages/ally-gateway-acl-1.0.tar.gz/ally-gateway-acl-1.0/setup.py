
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Gabriel Nistor',
      author_email='gabriel.nistor@sourcefabric.org',
      description='This plugin provides the service gateways.',
      install_requires=['ally-gateway >= 1.0', 'ally-core-http >= 1.0'],
      long_description='The ACL (access control layer) gateway plugin integrates gateways that are\ndesigned based on published REST models and services, basically makes the conversion between access allowed on a\nservice call and a gateway REST model.',
      name='ally-gateway-acl',
      version='1.0'
      )

