'''
Created on Feb 23, 2012

@package: GUI actions 
@copyright: 2011 Sourcefabric o.p.s.
@license: http://www.gnu.org/licenses/gpl-3.0.txt
@author: Mihai Balaceanu
'''
