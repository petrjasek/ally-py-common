
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Mihai Balaceanu',
      author_email='mihai.balaceanu@sourcefabric.org',
      description='Provides the the GUI actions',
      install_requires=['ally-api >= 1.0'],
      long_description=' Provides the services required for having actions that can be used by UI in order to define\napplication menus or other things that the server has an impact on.',
      name='ally-gui-action',
      version='1.0'
      )

