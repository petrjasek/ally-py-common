
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Gabriel Nistor',
      author_email='gabriel.nistor@sourcefabric.org',
      classifiers=['Development Status :: 4 - Beta'],
      description='Provides the means for packaging and publishing ally packages (components and plugins)',
      install_requires=['ally >= 1.0'],
      keywords=['Ally', 'distribution', 'packaging'],
      long_description='Contains support for packaging components and plugins.',
      name='ally-distribution',
      py_modules=['ally_distribution'],
      version='1.0'
      )

