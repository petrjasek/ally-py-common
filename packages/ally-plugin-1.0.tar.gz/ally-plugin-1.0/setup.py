
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Gabriel Nistor',
      author_email='gabriel.nistor@sourcefabric.org',
      classifiers=['Development Status :: 4 - Beta'],
      description='The plugin support for REST.',
      install_requires=['ally>=1.0'],
      keywords=['Ally', 'REST', 'plugin'],
      long_description='This component handles the plugins and incorporates them in the application.',
      name='ally-plugin',
      test_suite='__unit_test__',
      version='1.0'
      )

