
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Gabriel Nistor',
      author_email='gabriel.nistor@sourcefabric.org',
      description='Provides the the user security',
      install_requires=['ally-gateway-acl >= 1.0', 'ally-gui-action >= 1.0', 'ally-hr-user >= 1.0', 'ally-security-rbac >= 1.0'],
      keywords=['Ally', 'REST', 'plugin', 'security', 'user'],
      long_description='Authentication services based on the human resources users.',
      name='ally-security-user',
      version='1.0'
      )

