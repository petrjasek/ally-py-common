'''
Created on Jun 1, 2011

@package: support sqlalchemy
@copyright: 2011 Sourcefabric o.p.s.
@license: http://www.gnu.org/licenses/gpl-3.0.txt
@author: Nistor Gabriel

Contains basic sql alchemy specifications and implementations.
'''
