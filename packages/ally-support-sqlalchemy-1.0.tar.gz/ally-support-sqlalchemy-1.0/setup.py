
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Gabriel Nistor',
      author_email='gabriel.nistor@sourcefabric.org',
      description='Provides the support for SQL alchemy',
      install_requires=['ally-api >= 1.0', 'SQLAlchemy>=0.7.1'],
      keywords=['Ally', 'REST', 'framework', 'plugin', 'SQLAlchemy'],
      long_description='The [SQLAlchemy] support plugin that facilitates the work with SQL Alchemy object \nrelational mapping. Contains support for mapping REST models with SQL Alchemy, also support for transaction\nhandling at a request scope level. Has a central database application configuration but also the means of setting\na different or multiple databases.',
      name='ally-support-sqlalchemy',
      test_suite='__unit_test__',
      version='1.0'
      )

