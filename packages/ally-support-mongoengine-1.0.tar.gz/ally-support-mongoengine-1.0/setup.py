
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Gabriel Nistor',
      author_email='gabriel.nistor@sourcefabric.org',
      description='Provides the support for using Mongo engine ORM',
      install_requires=['ally-api >= 1.0', 'mongoengine >= 0.8.4'],
      keywords=['Ally', 'REST', 'framework', 'plugin', 'Mongo'],
      long_description='The [Mongo Engine] support plugin that facilitates the work with Mongo Engine object relational\nmapping. Contains support for mapping REST models with Mongo Documents.',
      name='ally-support-mongoengine',
      version='1.0'
      )

