
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Gabriel Nistor',
      author_email='gabriel.nistor@sourcefabric.org',
      description='Provides the managmenet for the localized messages',
      install_requires=['ally-api >= 1.0', 'ally-support-sqlalchemy >= 1.0', 'ally-support-cdm >= 1.0', 'Babel >= 1.3'],
      keywords=['Ally', 'REST', 'plugin', 'internationalization'],
      long_description=' Provides the services for managing PO and POT files.',
      name='ally-internationalization',
      version='1.0'
      )

