
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Gabriel Nistor',
      author_email='gabriel.nistor@sourcefabric.org',
      classifiers=['Development Status :: 4 - Beta'],
      description='Provides the HTTP communication support',
      install_requires=['ally >= 1.0'],
      keywords=['Ally', 'REST', 'http'],
      long_description='Contains HTTP specific handling for requests and also the basic HTTP server based on the python built in server.',
      name='ally-http',
      test_suite='__unit_test__',
      version='1.0'
      )

