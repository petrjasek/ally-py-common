'''
Created on Jul 15, 2011

@package: ally http
@copyright: 2012 Sourcefabric o.p.s.
@license: http://www.gnu.org/licenses/gpl-3.0.txt
@author: Gabriel Nistor

Contains the processors that are specific for HTTP data handling, for instance the URI to resource path processor or the
request content wrapper processor.
'''
