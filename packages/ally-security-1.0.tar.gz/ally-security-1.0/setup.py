
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Ioan Pocol',
      author_email='ioan.pocol@sourcefabric.org',
      description='This plugin provides the basic security models.',
      install_requires=['ally-api >= 1.0', 'ally-support-sqlalchemy >= 1.0'],
      keywords=['Ally', 'REST', 'plugin', 'support', 'security'],
      long_description=' Provides the basic services for organizing rights.',
      name='ally-security',
      version='1.0'
      )

