
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      description='Provides the gateway reCAPTCHA service',
      name='ally-service-gateway-recaptcha',
      version='1.0'
      )

