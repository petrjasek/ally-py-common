
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Gabriel Nistor',
      author_email='gabriel.nistor@sourcefabric.org',
      classifiers=['Development Status :: 4 - Beta'],
      description='Provides the core functionality for handling the REST API decorated services and models',
      install_requires=['ally-api >= 1.0', 'ally-indexing >= 1.0'],
      keywords=['Ally', 'core', 'REST'],
      long_description='Provides the general support for handling the [API] services that have been decorated as [REST] services.',
      name='ally-core',
      test_suite='__unit_test__',
      version='1.0'
      )

