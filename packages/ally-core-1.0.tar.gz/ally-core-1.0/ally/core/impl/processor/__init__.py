'''
Created on Jul 8, 2011

@package: ally core
@copyright: 2011 Sourcefabric o.p.s.
@license: http://www.gnu.org/licenses/gpl-3.0.txt
@author: Gabriel Nistor

Contains all the processor implementations that are general by nature this processors are either main processor or
specific ones for instance for decoding or encoding.
'''
