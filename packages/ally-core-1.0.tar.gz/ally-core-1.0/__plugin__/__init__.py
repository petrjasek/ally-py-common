'''
Created on Jul 15, 2011

@package: ally core
@copyright: 2012 Sourcefabric o.p.s.
@license: http://www.gnu.org/licenses/gpl-3.0.txt
@author: Gabriel Nistor

Special package that is targeted by the IoC for processing plugins.
'''
