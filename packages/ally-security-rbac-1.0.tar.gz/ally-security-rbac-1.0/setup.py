
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Ioan Pocol',
      author_email='ioan.pocol@sourcefabric.org',
      description='This plugin handles the support for RBAC security.',
      install_requires=['ally-security >= 1.0'],
      keywords=['Ally', 'REST', 'plugin', 'support', 'RBAC'],
      long_description=' Provides the services for organizing rights based on roles or other entities.',
      name='ally-security-rbac',
      version='1.0'
      )

