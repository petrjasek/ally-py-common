
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Gabriel Nistor',
      author_email='gabriel.nistor@sourcefabric.org',
      classifiers=['Development Status :: 4 - Beta'],
      description='Provides the HTTP communication support',
      install_requires=['ally-core >= 1.0', 'ally-http >= 1.0'],
      keywords=['Ally', 'REST', 'core', 'http '],
      long_description='This component provides the actual handling for the HTTP [REST] by combining the ally-core and ally-http.',
      name='ally-core-http',
      test_suite='__unit_test__',
      version='1.0'
      )

