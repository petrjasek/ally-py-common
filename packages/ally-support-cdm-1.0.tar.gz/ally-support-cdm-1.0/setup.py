
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Gabriel Nistor',
      author_email='gabriel.nistor@sourcefabric.org',
      description='Provides the cdm file system service',
      install_requires=['ally >= 1.0'],
      keywords=['Ally', 'REST', 'plugin', 'cdm'],
      long_description=' The content delivery manager support for publishing binary resources to different platforms.',
      name='ally-support-cdm',
      version='1.0'
      )

