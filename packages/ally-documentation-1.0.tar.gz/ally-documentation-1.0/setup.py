
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Gabriel Nistor',
      author_email='gabriel.nistor@sourcefabric.org',
      classifiers=['Development Status :: 4 - Beta'],
      description='Provides automatically generated documentation for REST services and models',
      install_requires=['ally-core-http >= 1.0', 'jinja2 >= 2.6'],
      keywords=['Ally', 'documentation', 'REST'],
      long_description='Provides the documentation support for the [API] services adn models.',
      name='ally-documentation',
      version='1.0'
      )

