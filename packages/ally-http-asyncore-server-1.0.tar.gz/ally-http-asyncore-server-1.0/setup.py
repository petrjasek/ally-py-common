
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Gabriel Nistor',
      author_email='gabriel.nistor@sourcefabric.org',
      classifiers=['Development Status :: 4 - Beta'],
      description='Provides the HTTP asyncore server',
      install_requires=['ally-http >= 1.0'],
      keywords=['Ally', 'REST', 'HTTP', 'asyncore', 'server'],
      long_description='Provides an HTTP server substitute for the basic server from ally-http \nthat handles the requests in an asyncore manner by using the python built in asyncore package.',
      name='ally-http-asyncore-server',
      test_suite='__unit_test__',
      version='1.0'
      )

