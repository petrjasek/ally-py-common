
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Gabriel Nistor',
      author_email='gabriel.nistor@sourcefabric.org',
      description='This plugin provides the default gateway service.',
      install_requires=['ally-support-sqlalchemy >= 1.0'],
      long_description='This plugin provides the Gateway API and also the means of setting up custom gateways,\nfor instance allowing for a certain IP full access to REST models. The gateway plugin is agnostic to the actual\nservices that are published by the REST server and any type of URLs and rules can be placed with this plugin.',
      name='ally-gateway',
      version='1.0'
      )

