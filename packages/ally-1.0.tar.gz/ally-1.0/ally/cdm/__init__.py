'''
Created on Jan 5, 2012

@package: ally base
@copyright: 2011 Sourcefabric o.p.s.
@license: http://www.gnu.org/licenses/gpl-3.0.txt
@author: Mugur Rus

Contains the Content Delivery Manager (CDM) classes

CDM receives content through it's interface and publishes it
through a web server.
'''
