'''
Created on Jan 11, 2012

@package: ally base
@copyright: 2011 Sourcefabric o.p.s.
@license: http://www.gnu.org/licenses/gpl-3.0.txt
@author: Gabriel Nistor

Provides the implementations for the container. This package is intended only for internal use.
ATENTION DO NOT USE DIRECTLY ANY MODULES OR CLASSES FROM THIS PACKAGE!
'''
