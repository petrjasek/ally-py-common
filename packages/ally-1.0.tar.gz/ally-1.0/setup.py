
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Gabriel Nistor',
      author_email='gabriel.nistor@sourcefabric.org',
      classifiers=['Development Status :: 4 - Beta'],
      description='Ally framework - utilities component',
      install_requires=['PyYAML==3.10'],
      keywords=['Ally', 'REST'],
      long_description='This is the main component and is the application entry point. \nThis component provides also support for inversion of control container.\nBasically this component contains general support for the application that is not in any way linked with a\nparticular technology.',
      name='ally',
      py_modules=['ally_start', 'package_extender'],
      test_suite='__unit_test__',
      version='1.0'
      )

