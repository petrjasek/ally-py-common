
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Gabriel Nistor',
      author_email='gabriel.nistor@sourcefabric.org',
      classifiers=['Development Status :: 4 - Beta'],
      description='Provides the REST API support for marking REST services and models',
      install_requires=['ally >= 1.0'],
      keywords=['Ally', 'REST', 'API'],
      long_description='Contains support for marking the models and services.',
      name='ally-api',
      test_suite='__unit_test__',
      version='1.0'
      )

