
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Gabriel Nistor',
      author_email='gabriel.nistor@sourcefabric.org',
      description='Provides the patch as per Praha office request',
      install_requires=['ally-core-http >= 1.0'],
      keywords=['Ally', 'patch', 'praha'],
      long_description=' Contains the patches for Praha office UI requirements.',
      name='ally-patch-praha',
      version='1.0'
      )

