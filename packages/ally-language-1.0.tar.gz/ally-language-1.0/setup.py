
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Gabriel Nistor',
      author_email='gabriel.nistor@sourcefabric.org',
      description='Provides the languages',
      install_requires=['ally-api >= 1.0', 'ally-support-sqlalchemy >= 1.0'],
      keywords=['Ally', 'REST', 'plugin', 'language'],
      long_description='Language management functionality (model, service)',
      name='ally-language',
      test_suite='__unit_test__',
      version='1.0'
      )

