
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Gabriel Nistor',
      author_email='gabriel.nistor@sourcefabric.org',
      description='Provides the users services',
      install_requires=['ally-api >= 1.0', 'ally-support-sqlalchemy >= 1.0'],
      keywords=['Ally', 'REST', 'human', 'resources', 'plugin', 'users'],
      long_description=' User management functionality (model, service).',
      name='ally-hr-user',
      version='1.0'
      )

