
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Gabriel Nistor',
      author_email='gabriel.nistor@sourcefabric.org',
      description='The plugin that provides the indexing support.',
      install_requires=['ally-api >= 1.0', 'ally-core >= 1.0'],
      long_description='This plugin offers the Indexing API and the implementation provides details related to \nthe REST models content response indexing based on data associate with ally-core.',
      name='ally-indexing-provider',
      version='1.0'
      )

