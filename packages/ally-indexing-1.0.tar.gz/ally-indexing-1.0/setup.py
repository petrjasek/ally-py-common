
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Gabriel Nistor',
      author_email='gabriel.nistor@sourcefabric.org',
      classifiers=['Development Status :: 4 - Beta'],
      description='Provides the support for content indexing and content transformation',
      install_requires=['ally >= 1.0'],
      keywords=['Ally', 'REST', 'indexing'],
      long_description='Provides support for tagging content with indexes and support to manipulate those indexes for \ncontent transformation.',
      name='ally-indexing',
      version='1.0'
      )

