
from setuptools import setup, find_packages

# --------------------------------------------------------------------

setup(platforms=['all'],
      zip_safe=True,
      license='GPL v3',
      url='http://www.sourcefabric.org/en/superdesk/',
      packages=find_packages('.'),
      author='Gabriel Nistor',
      author_email='gabriel.nistor@sourcefabric.org',
      classifiers=['Development Status :: 4 - Beta'],
      description='Provides the assemblage service',
      install_requires=['ally-http >= 1.0', 'ally-indexing >= 1.0'],
      keywords=['Ally', 'REST', 'gateway', 'service', 'assemblage'],
      name='ally-service-assemblage',
      test_suite='__unit_test__',
      version='1.0'
      )

